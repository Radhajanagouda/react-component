/// <reference types="cypress" />
import React from 'react';
// import { mount } from 'cypress-react-unit-test';
import { Item } from './item';
// import app's style so the footer looks real
import 'todomvc-app-css/index.css';

describe('Item component', () => {
  it('calls onClearCompleted if there are completed items', () => {
    cy.mount(
      <section className="todoapp">
        <Item id={1} name={todoItem} completed={false} />
      </section>
    );
    // component is running like a mini web app
    // we can interact with it using normal Cypress commands
    // https://on.cypress.io/api
    // cy.contains('Clear completed').click();
    // cy.get('@clear').should('have.been.calledOnce');
  });
});
