import { ACTION_TYPES } from '../../constants/action-type';

export const onFilterSelect = filter => ({ type: ACTION_TYPES.selectFilter, filter });
