export const FILTERS = {
  all: 'all',
  active: 'active',
  completed: 'completed'
};
